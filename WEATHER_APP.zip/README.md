A little and simple weather app created to understand how to use an API in JS, I hope you like it
Made it using this video: https://www.youtube.com/watch?v=MIYQR-Ybrn4&list=PLjwm_8O3suyOgDS_Z8AWbbq3zpCmR-WE9
